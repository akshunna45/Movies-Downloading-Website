-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2019 at 11:02 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `authentication`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `comment` text NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `movie_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `id` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `date` varchar(50) NOT NULL,
  `genres` varchar(100) NOT NULL,
  `cast` varchar(100) NOT NULL,
  `language` varchar(100) NOT NULL,
  `quality` varchar(100) NOT NULL,
  `subtitle` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`id`, `title`, `date`, `genres`, `cast`, `language`, `quality`, `subtitle`) VALUES
('10E_15.php', '10 Endrathukulla (10 Ka Dum) 2015 720p Hindi HDRip Dual Audio Full Movie', '21 October 2015', 'Action', 'Pasupathy, Rahul Dev, Samantha Ruth Prabhu', 'Hindi, Tamil', '720p HDRip', 'English'),
('22Y_19.php', '22 Yards (2019) Full Movie Hindi 720p HDRip Free Download', '15 March 2019', 'Drama', 'Barun Sobti, Panchhi Bora, Rajit Kapur', 'Hindi', '720p HDRip', ''),
('706_19.php', '706 (2019) Full Movie [Hindi-DD5.1] 720p HDRip ESubs Download', '11 January 2019', '', 'Divya Dutta, Mohan Agashe, Raayo S. Bakhirta', 'Hindi DD5.1', '720p BluRay', 'English'),
('A15_19.php', 'Article 15 (2019) Full Movie [Hindi-DD5.1] 720p HDRip ESubs Download', '28 June 2019', 'Drama, Crime', 'Ayushmann Khurrana, Isha Talwar, Manoj Pahwa', 'Hindi', '720p HDRip', 'English'),
('AEG_19.php', 'Avengers: Endgame (2019) Dual Audio [Hindi-Cleaned] 720p BluRay ESubs Download', '24 April 2019', 'Action, Adventure, Sci-Fi', 'Chris Evans, Mark Ruffalo, Robert Downey Jr.', 'Hindi, English', '720p BluRay', 'English'),
('AIW_18.php', 'Avengers Infinity War (2018) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '26 April 2018', 'Action Adventure Sci-Fi', 'Chris Hemsworth, Mark Ruffalo, Robert Downey Jr.', 'Hindi DD5.1, English', '720p HDRip', 'English'),
('ASS_11.php', 'All-Star Superman (2011) Full Movie [English-DD5.1] 720p BluRay ESubs Download', '22 February 2011', 'Action, Adventure, Animation', 'Anthony LaPaglia, Christina Hendricks, James Denton', 'English DD5.1', '720p BluRay', 'English'),
('A_99.php', 'Aarzoo (1999) Full Movie Hindi 720p HDRip ESubs Download', '19 March 1999', 'Drama', 'Akshay Kumar, Madhuri Dixit, Saif Ali Khan', 'Hindi', '720p HDRip', 'English'),
('BAMFS_98.php', 'Batman & Mr. Freeze: SubZero (1998) Dual Audio [Hindi-English] 720p BluRay ESubs Download', '17 March 1998', 'Animation, Action, Crime', 'Kevin Conroy, Loren Lester, Michael Ansara', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('BH_19.php', 'Batman: Hush (2019) Full Movie [English-DD5.1] 720p BluRay ESubs Download', '20 July 2019', 'Animation, Advanture, Action', 'Jason O\'Mara, Jennifer Morrison, Peyton List', 'English DD5.1', '720p BluRay', 'English'),
('BMB_13.php', 'Bhaag Milkha Bhaag (2013) Full Movie [Hindi-DD5.1] 720p BluRay ESubs Download', '12 July 2013', 'Biography, Drama, History', 'Farhan Akhtar, Pavan Malhotra, Sonam Kapoor', 'Hindi DD5.1', '720p HDRip', 'English'),
('BMOTB_03.php', 'Batman:Mystery of the Batwoman (2003) Full Movie [English-DD5.1] 720p BluRay ESubs Download', '06 November 2003', 'Animation Action Comedy', 'Kelly Ripa, Kevin Conroy, Kimberly Brooks', 'English DD5.1', '720p BluRay', 'English'),
('BMOTP_93.php', 'Batman Mask of the Phantasm (1993) Dual Audio [Hindi-English] 720p BluRay ESubs Download', '25 December 1993', 'Animation, Action, Adventure', 'Kevin Conroy, Dana Delany, Hart Bochner', 'Hindi, English', '720p BluRay', 'English'),
('BOSS_S1.php', 'BOSS – Baap of Special Services 2019 Hindi Season 1 WEB Series All Episodes free download', '02 August 2019', 'Action', 'Karan Singh Grover, Sagarika Ghatge, Dalljiet Kaur', 'Hindi', '720p WEB-DL', ''),
('BYBM_19.php', 'Bodhai Yeri Budhi Maari (2019) Tamil Full Movie 720p HDRip 1.6GB ESub', '12 July 2019', 'Drama Thriller', 'Charlie, Dheeraj, Dushara', 'Hindi', '720p HDRip', 'English'),
('B_08.php', 'Bolt (2008) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '22 January 2009', 'Animation Adventure Comedy', 'John Travolta, Miley Cyrus', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('B_11.php', 'Badrinath (2011) Dual Audio [Hindi-Tamil] 720p BluRay ESubs Download', '10 June 2011', 'Drama, Action', 'Allu Arjun, Prakash Raj, Tamannaah Bhatia', 'Hindi, Tamil', '720p BluRay', 'English'),
('C2_18.php', 'Creed II (2018) Full Movie [English-DD5.1] 720p BluRay ESubs Download', ' 24 January 2019', ' Drama, Sport', 'Michael B. Jordan, Sylvester Stallone, Tessa Thompson', 'English DD5.1', '720p BluRay', 'English'),
('CE_13.php', 'Chennai Express (2013) Full Movie [Hindi-DD5.1] 720p BluRay ESubs Download', '15 August 2015', ' Drama, Action', 'Deepika Padukone, Sathyaraj, Shah Rukh Khan', ' Hindi DD5.1', ' 720p BluRay', 'English'),
('CM_19.php', 'Captain Marvel (2019) Dual Audio [Hindi-English] 720p BluRay ESubs Download', ' 07 March 2019', 'Action, Adventure, Sci-Fi', 'Ben Mendelsohn, Brie Larson, Samuel L. Jackson', 'Hindi(DTH Audio), English', '720p HDRip', 'English'),
('C_15.php', 'Creed (2015) Dual Audio [Hindi-English] 720p BluRay ESubs Download', '14 January 2016', 'Drama, Sport', 'Michael B. Jordan, Sylvester Stallone, Tessa Thompson', 'English DD5.1', '720p BluRay', 'English'),
('D2_18.php', 'Deadpool 2 (2018) Extended Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', ' 17 May 2018', 'Action, Adventure, Comedy', 'Josh Brolin, Morena Baccarin, Ryan Reynolds', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('DB_11.php', 'Desi Boyz (2011) Full Movie [Hindi-DD5.1] 720p BluRay ESubs Download', '25 November 2011', 'Comedy, Drama', 'Akshay Kumar, Deepika Padukone, John Abraham', 'Hindi DD5.1', '720p HDRip', 'English'),
('DHRUVA_16.php', ' Dhruva 2016 Hindi Dubbed 720p HDRip Full Movie x264 Download', '09 December 2016', ' Action, Thriller', 'Arvind Swamy, Farah Karimaee, Nassar', 'Hindi', '720p HDRip', ''),
('DKD_09.php', 'Do Knot Disturb (2009) Full Movie [Hindi-DD5.1] 720p DVDRip ESubs Download', '02 October 2009', 'Drama', 'Govinda, Riteish Deshmukh, Sushmita Sen', 'Hindi DD5.1', '720p DVDRip', 'English'),
('D_15.php', 'Dynamite (2015) Hindi Dubbed ORG 720p HDRip 1.4GB Full Movie Download', '03 September 2015', 'Action', 'J.D. Chakravarthi, Nagineedu, Venkateswara Rao Paruchuri', 'Hindi, Tamil', '720p HDRip', ''),
('D_16.php', 'Deadpool (2016) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '17 May 2018', ' Action, Adventure, Comedy', 'Morena Baccarin, Ryan Reynolds, T.J. Miller', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('FN_03.php', 'Finding Nemo (2003) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '20 November 2003', 'Animation, Comedy, Adventure', 'Albert Brooks, Alexander Gould, Ellen DeGeneres\r\n', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('F_17.php', 'Firangi (2017) Full Movie Hindi 720p HDTVRip Free Download', '01 December 2017', 'Drama', 'Ishita Dutta, Kapil Sharma, Monica Gill', 'Hindi', '720p HDTV', ''),
('GA_17.php', 'Gnome Alone (2017) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '14 October 2018', 'Animation, Adventure, Comedy', 'Becky G, Josh Peck, Tara Strong', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('GKOTM_19.php', 'Godzilla: King of the Monsters (2019) Dual Audio [Hindi-Cleaned] 720p HC HDRip Free Download', '30 May 2019', 'Action, Adventure, Fantasy', 'Kyle Chandler, Millie Bobby Brown, Vera Farmiga', 'Hindi(Cleaned), English', '720p HDRip', ''),
('GLEK_11.php', 'Green Lantern: Emerald Knights (2011) Full Movie [English-DD5.1] 720p BluRay ESubs Download', '07 June 2011', 'Animation, Action Adventure', 'Elisabeth Moss, Jason isaacs, Nathan Fillion', ' English DD5.1', '720p BluRay', 'English'),
('GOT_S1.php', 'Game of Thrones S01 Complete Dual Audio 720p BRRip [Hindi – English]', '17 April 2011', 'Action, Adventure, Drama', 'Emilia Clarke, Peter Dinklage, Kit Harington', 'Hindi, English', '720p BluRay', 'English'),
('GOT_S2.php', 'Game of Thrones S02 Complete Hindi Dual Audio 720p BRRip ESubs', '10 April 2012', 'Action, Adventure, Drama', 'Emilia Clarke, Peter Dinklage, Kit Harington', 'Hindi, English', '720p BluRay', 'English'),
('GOT_S3.php', 'Game of Thrones S03 All Episodes Dual Audio Hindi 480p BRRip 1.7GB', '10 April 2012', 'Action, Adventure, Drama', 'Emilia Clarke, Peter Dinklage, Kit Harington', ' Hindi, English', '720p BluRay', 'English'),
('GOT_S4.php', 'Game of Thrones Season 4 Dual Audio [Hindi-English] 720p BluRay ESubs Download', '23 March 2012', 'Action, Adventure, Drama', 'Emilia Clarke, Peter Dinklage, Kit Harington', 'Hindi, English', '720p BluRay', 'English'),
('GOT_S5.php', 'Game of Thrones S05 Complete English 720p BRRip 5.2GB free Download', '12 April 2012', ' Action, Adventure, Drama', 'Emilia Clarke, Peter Dinklage, Kit Harington', 'English', '720p BluRay', 'English'),
('GOT_S6.php', 'Game of Thrones Season 6 Complete 720p BluRay With ESubs Download', '24 April 2017', 'Action, Adventure, Drama', 'Emilia Clarke, Peter Dinklage, Kit Harington', 'English', '720p BluRay', 'English'),
('GOT_S7.php', 'Game of Thrones S07 Complete English 720p WEB-DL 4GB free Download', '16 July 2017', 'Action, Adventure, Drama', 'Emilia Clarke, Peter Dinklage, Kit Harington', 'Hindi, English', '720p BluRay', 'English'),
('GOT_S8.php', 'Game of Thrones S08 Complete Hindi Dubbed 720p HDRip [Ep 03 Added]', '15 July 2016', 'Action, Adventure, Drama', 'Peter Dinklage, Nikolaj Coster-Waldau, Lena Headey', 'Hindi, English', '720p BluRay', 'English'),
('IM_16.php', 'Iru Mugan (2016) 720p Tamil HDRip Full Movie Download', '09 September 2016', 'Action, Sci-Fi', 'Nassar, Nayanthara, Nithya Menon, Vikram', 'Hindi, Tamil', '720p HDRip', ''),
('ITB_S1.php', 'Into The Badlands Season 1 Dual Audio Hindi Complete 720p BRRip 2.6GB Free Download', '15 November 2015', 'Action, Adventure, Drama', 'Daniel Wu, Emily Beecham, Orla Brady', 'Hindi, English', '720p BRRip', ''),
('ITB_S2.php', 'Into the Badlands Season 2 Dual Audio Hindi Complete 720p WEBRip 4.3GB free download', '17 March 2017', 'Drama, Action, Adventure', 'Daniel Wu, Emily Beecham, Orla Brady', 'Hindi, English', '720p WEB-DL', ''),
('ITB_S3.php', 'Into The Badlands Season 3 Hindi Dubbed WEB Series All Episodes Download', '08 August 2019', 'Action, Adventure, Drama', 'Daniel Wu, Orla Brady, Emily Beecham', 'Hindi DD5.1, English', '720p HDRip', 'English'),
('JLCOTE_10.php', 'Justice League Crisis on Two Earths (2010) Full Movie [English-DD5.1] 720p BluRay ESubs Download', '23 April 2010', 'Action, Adventure', 'Chris Noth, Mark Harmon, William Baldwin', 'English DD5.1', '720p BluRay', 'English'),
('JLD_12.php', 'Justice League Doom (2012) Full Movie [English-DD5.1] 720p BluRay ESubs Download', '28 February 2012', 'Action, Adventure', 'Kevin Conroy, Susan Eisenberg, Tim Daly', 'English DD5.1', '720p BluRay', 'English'),
('JWC2_17.php', 'John Wick: Chapter 2 (2017) Dual Audio [Hindi-English] 720p BluRay ESubs Download', '16 Februrary 2016', 'Action, Crime, Thriller', 'Riccardo Scamarcio, Ian McShane, Keanu Reeves', 'Hindi, English', '720p BluRay', 'English'),
('JWC3_19.php', 'John Wick: Chapter 3 Parabellum (2019) Full Movie [English-DD5.1] 720p BluRay ESubs Download', '23 May 2019', 'Action, Crime, Thriller', 'Halle Berry, Ian McShane, Keanu Reeves', 'English DD5.1', '720p BluRay', 'English'),
('JW_14.php', 'John Wick (2014) Dual Audio [Hindi-English] 720p BluRay ESubs Download', '19 January 2015', 'Action, Crime, Thriller', 'Alfie Allen, Keanu Reeves, Michael Nyqvist', 'Hindi, English', '720p BluRay', 'English'),
('K13_19.php', 'K-13 (2019) Tamil 720p HDTVRip 1GB Free Download', '03 May 2019', 'Thriller, Drama', 'Arulnithi, ‎Shraddha Srinath, Ramesh Thilak', 'Hindi, Tamil', '720p HDTV', ''),
('K2_16.php', 'Kanchana 2 (2016) UnCut 720p HDRip Hindi Dubbed Full Movie Download', '17 April 2015', 'Action, Horror, Romance', 'Lawrence Raghavendra, Nithya Menon, Tapsee Pannu', 'Hindi', '720p HDRip', 'English'),
('KKHH_05.php', 'Kyaa Kool Hai Hum (2005) Full Movie Hindi 720p HDRip Free Download', '06 May 2005', 'Drama, Romance', 'Isha Koppikar, Riteish Deshmukh, Tusshar Kapoor', 'Hindi', '720p HDRip', ''),
('KK_19.php', 'Kadaram Kondan 2019 Tamil 720p WEB-DL 850MB ESubs Free Download', '19 July 2019', 'Action, Thriller', 'Vikram, Akshara Haasan, Abi Hassan', 'Tamil', '720p HDRip', 'English'),
('KM2_11.php', 'Kanchana Muni 2 (2011) 720p HDRip Hindi Dubbed Full Movie Download', '15 August 2011', 'Crime, Horror', 'Kovai Sarala,, Lawrence Raghavendra, Raai Laxmi', 'Hindi', '720p HDRip', 'English'),
('KN150_17.php', 'Khaidi No. 150 (2017) Dual Audio Hindi HDRip 720p 1.4GB Free Download', '11 January 2017', 'Action, Comedy, Drama', 'Chiranjeevi, Kajal Aggarwal, Tarun Arora', 'Hindi DD2.0', '720p HDRip', 'English'),
('KSKHH_12.php', 'Kyaa Super Kool Hain Hum (2012) Full Movie Hindi 720p HDRip ESubs Download', '27 July 2012', 'Drama, Romance', 'Neha Sharma, Riteish Deshmukh, Tusshar Kapoor', 'Hindi', '720p HDRip', 'English'),
('LGN_17.php', 'Logan (2017) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '02 March 2017', 'Action, Drama, Sci-Fi', 'Dafne Keen, Hugh Jackman, Patrick Stewart', 'Hindi DD5.1', '720p BluRay', 'English'),
('L_17.php', 'Life (2017) Dual Audio [Hindi-English] 720p BluRay ESubs Download', '23 March 2017', 'Horror, Sci-Fi, Thriller', 'Jake Gyllenhaal, Rebecca Ferguson, Ryan Reynolds', 'Hindi, English', '720p BluRay', 'English'),
('L_18.php', 'Lupt (2019) Full Movie [Hindi-DD5.1] 720p HDRip ESubs Download', '02 November 2019', ' Comedy, Drama', 'Javed Jaffrey, Karan Aanand, Vijay Raaz', 'Hindi DD5.1', '720p HDRip', 'English'),
('MEI_19.php', 'MEI (2019) Tamil 720p DVDScr 1GB & 400MB Full Movie Download', '23 August 2019', 'Crime, Drama', 'Nicky Sundaram, Aishwarya Rajesh, Vinod Krishnan', 'Hindi', '720p HDRip', ''),
('MIB2_02.php', 'Men in Black II (2002) Dual Audio [Hindi-DD5.1] 1080p BluRay ESubs Download', '18 July 2002', 'Action, Adventure, Comedy', 'Rip Torn, Tommy Lee, Will Smith', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('MIB3_12.php', 'Men in Black 3 (2012) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '24 May 2012', 'Action, Adventure, Comedy', 'Josh Brolin, Tommy Lee Jones, Will Smith', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('MIBI_19.php', 'Men in Black: International (2019) Dual Audio [Hindi-Cleaned] 720p HDRip ESubs Download', '13 June 2019', 'Action, Adventure, Comedy', 'Chris Hemsworth, Kumail Nanjiani, Tessa Thompson', 'Hindi(Cleaned), English', '720p HDRip', 'English'),
('MIB_97.php', 'Men in Black (1997) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '11 September 1997', 'Action, Adventure, Comedy', 'Linda Fiorentino, Tommy Lee Jones, Will Smith', 'Hindi DD5.1, English', '720p HDRip', 'English'),
('MKDNH_19.php', 'Mard Ko Dard Nahi Hota (2019) Full Movie [Hindi-DD5.1] 720p HDRip ESubs Download', '21 March 2019', 'Action, Comedy', 'Abhimanyu Dasani, Gulshan Devaiah, Riva Arora\r\n', 'Hindi DD5.1', '720p HDRip', 'English'),
('MVA_09.php', 'Monsters vs. Aliens (2009) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '02 April 2009', 'Animation, Adventure, Action', 'Reese Witherspoon, Rainn Wilson, Stephen Colbert', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('MZ_16.php', 'Mastizaade (2016) Full Movie [Hindi-DD5.1] 720p HDRip ESubs Download', '29 January 2016', 'Comedy, Drama', 'Ishita Chauhan, Mona Ambegaonkar, Shiney Ahuja', 'Hindi', '720p HDRip', ''),
('M_15.php', 'Maari 2015 UnCut 720p Hindi HDRip Dual Audio Full Movie Download', '17 July 2015', 'Action, Comedy, Drama', 'Dhanush, Kajal Aggarwal, Robo Shankar, Vijay Yesudas', 'Hindi DD2.0, Tamil DD5.1', '720p HDRip', ''),
('N_16.php', 'Neerja (2016) Hindi 720p BRRip Full Movie Download', '19 February 2016', 'Biography, Thriller, Drama', 'Abrar Zahoor, Shabana Azmi, Sonam Kapoor', 'Hindi DD5.1', '720p BluRay', 'English'),
('ODJD_19.php', 'One Day: Justice Delivered (2019) Full Movie Hindi 720p HDTVRip Free Download', '05 July 2019', 'Action, Crime, Thriller', 'Anupam Kher, Esha Gupta, Kumud Mishra', 'Hindi', '720p HDTV', ''),
('OKK_18.php', 'Oru Kuppai Kathai (2018) Tamil Movie 720p HDRip 800MB ESubs Download', '25 May 2018', 'Comedy, Drama', 'Dinesh, ‎ Manisha Yadav, Sujo Mathew', 'Hindi, Tamil', '720p BluRay', ''),
('P_18.php', 'Paadam (2018) Tamil 720p WEB-DL 1.2GB Free Download', '20 April 2018', 'Drama', 'Yashika Aannand, ‎Karthik, Vijith', 'Hindi', '720p HDRip', ''),
('RAW_19.php', 'Romeo Akbar Walter (2019) Full Movie [Hindi-DD5.1] 720p HDRip ESubs Download', '5 April 2019', 'Action, Drama, Thriller', 'Jackie Shroff, John Abraham, Mouni Roy', 'Hindi DD5.1', '720p HDRip', 'English'),
('RR_13.php', 'R… Rajkumar (2013) Full Movie [Hindi-DD5.1] 720p BluRay ESubs Download', ' 06 December 2013', 'Action', 'Shahid Kapoor, Sonakshi Sinha, Sonu Sood', 'Hindi DD5.1', '720p BluRay', 'English'),
('R_16.php', 'Remo 2016 Full Movie 720p Tamil HDRip With ESubs Free Download', '07 October 2016', 'Comedy, Romance', 'Aadukalam Naren, Kalyani N., Siva Karthikeyan', 'Hindi, Tamil', '720p HDRip', 'English'),
('SBA_10.php', 'Superman/Batman Apocalypse (2010) Full Movie [English-DD5.1] 720p BluRay ESubs Download', ' 28 September 2010', 'Actiom, Adventure', 'Andre Braugher, Kevin Conroy, Tim Daly', 'English DD5.1', '720p BluRay', 'English'),
('SG_S1.php', 'Sacred Games Season 1 Complete [Hindi-DD5.1] 720p HDRip ESubs Download', '15 August 2019', 'Action, Drama, Crime', 'Nawazuddin Siddiqui, Radhika Apte, Saif Ali Khan', 'Hindi DD5.1', '720p HDRip', 'English'),
('SG_S2.php', 'Sacred Games Season 2 Complete [Hindi-DD5.1] 720p HDRip ESubs Download', '15 August 2019', 'Action, Drama, Crime', 'Nawazuddin Siddiqui, Radhika Apte, Saif Ali Kha', 'Hindi DD5.1', '720p HDRip', 'English'),
('SMITSV_18.php', 'Spider-Man Into the Spider-Verse (2018) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '13 DEcember 2018', 'Action, Adventure', 'Hailee Steinfeld, Jake Johnson, Shameik Moore', 'Hindi DD5.1 + English', '720p BluRay', 'English'),
('SM_08.php', 'Slumdog Millionaire 2008 Dual Audio Hindi 720p BluRay 950mb Free Download', '25 December 2005', 'Drama, Romance', 'Dev Patel, Freida Pinto, Saurabh Shukla', 'Hindi', '720p BluRay', ''),
('SOTY2_19.php', 'Student of the Year 2 (2019) Full Movie [Hindi-DD5.1] 720p HDRip ESubs Download', '10 May 2019', 'Comedy, Drama, Romance', 'Will Smith, Alia Bhatt, Tiger Shroff', 'Hindi', '720p WEB-DL', ''),
('STB_07.php', 'Sivaji The Boss (2007) Full Movie Hindi 720p BluRay ESubs Download', '15 June 2007', 'Drama, Thriller', 'Rajinikanth, Shriya Saran, Nayanthara Vivek', 'Hindi', '720p HDRip', 'English'),
('ST_S1.php', 'Stranger Things S01 Complete Dual Audio 720p Free Download', '15 July 2016', 'Sci-Fi, Horror', 'Maya Hawke, Jake Busey , Francesca Reale', 'Hindi, English', '720p BluRay\r\n', 'English'),
('ST_S2.php', 'Stranger Things S02 Dual Audio Hindi Complete 720p WEB-DL 3.6GB free download', '27 October 2017', 'Drama, Fantasy Horror', 'Dacre Montgpmery, Maya Hawke, Natalia Dyer', 'Hindi, English', '720p WEB-DL', ''),
('ST_S3.php', 'Stranger Things S03 Complete Dual Audio 720p Free Download', '15 July 2016', 'Sci-Fi, Horror', 'Maya Hawke, Jake Busey , Francesca Reale', 'Hindi, English', '720p BluRay', 'English'),
('S_00.php', 'Snatch (2000) Dual Audio [Hindi-English] 720p BluRay ESubs Download', '22 March 2001', 'Crime, Comedy', 'Benicio Del Toro, Brad Pitt, Jason Statham', 'Hindi, English', '720p BluRay', 'English'),
('S_15.php', 'Shamitabh (2015) Full Movie Hindi 720p HDRip ESubs Download', 'Drama', '06 February 2015', 'Akshara Haasan, Amitabh Bachchan, Dhanush', 'Hindi', '720p BluRay', 'English'),
('S_16.php', 'Sarbjit (2016) Full Movie [Hindi-DD5.1] 720p BluRay ESubs Download', '26 May 2016', 'Drama', 'Aishwarya Rai Bachchan, Randeep Hooda, Richa Chadha', 'Hindi DD5.1', '720p BluRay', 'English'),
('S_18.php', 'Sarkar (2018) Tamil 720p WEB-DL 1.1GB ESubs Free Download', '06 November 2018', 'Action, Drama', 'Joseph Vijay, Keerthi Suresh, A.R. Murugadoss', 'Hindi, Tamil', '720p HDRip', 'Tamil'),
('S_19.php', 'Saaho (2019) Tamil Full Movie 720p PreDVD 1.4GB Free Download', '29 August 2019', 'Action, Drama', 'Prabhas, Shraddha Kapoor, Chunky Panday', 'Hindi', '720p HDRip', ''),
('TABM_16.php', 'The Angry Birds Movie (2016) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '12 May 2016', 'Animation, Action, Comedy', 'Danny McBride, Jason Sudeikis, Josh Gad', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('TAPM_19.php', 'The Accidental Prime Minister (2019) Full Movie Hindi 720p HDRip ESubs Download', '11 January 2019', 'Drama, Political Cinema', 'Aahana Kumar, Anupam Kher, Arjun Mathur', 'Hindi', '720p HDRip', 'English'),
('TBVD_05.php', 'The Batman vs. Dracula (2005) Dual Audio [Hindi-English] 720p HDRip ESubs Download', '18 October 2005', 'Animation, Action, Horror', 'Peter Stormare, Rino Romano, Tara Strong', 'Hindi, English', '720p HDRip', ' English'),
('TC_13.php', 'The Croods (2013) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '21 March 2013', 'Animation, Comedy, Adventure', 'Emma Stone, Nicolas Cage', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('TH2_11.php', 'The Hangover Part II (2011) Dual Audio [Hindi-English] 720p BluRay ESubs Download', '02 June 2011', 'Comedy, Mystery', 'Bradley Cooper, Ed Helms, Zach Galifianakis', 'Hindi, English', '720p BluRay', 'English'),
('TH3_13.php', 'The Hangover Part III (2013) Dual Audio [Hindi-English] 720p BluRay ESubs Download', '30 May 2013', 'Comedy, Adventure, Crime', 'Bradley Cooper, Ed Helms, Zach Galifianakis', 'Hindi, English', '720p BluRay', 'English'),
('TH_09.php', 'The Hangover (2009) UnRated Dual Audio [Hindi-English] 720p BluRay ESubs Download', '23 July 2009', 'Comedy', 'Bradley Cooper, Justin Bartha, Zach Galifianakis', ' Hindi, English', '720p BluRay', 'English'),
('TLK_19.php', 'The Lion King (2019) Dual Audio [Hindi-Cleaned] 720p HDCAM Free Download', '17 July 2019', 'Animation, Advanture, Drama', 'Beyonce, Donald Glover, Seth Rogen', 'Hindi(Cleaned), English', '720p CAMRip', ''),
('TSLOP2_19.php', 'The Secret Life of Pets 2 (2019) Dual Audio [Hindi-Cleaned] 720p BluRay ESubs Download', '27 June 2019', 'Animation, Adventure, Comedy', 'Harrison Fordt, Kevin Hart, Patton Oswalt', 'Hindi(Cleaned), English', '720p BluRay', 'English'),
('TSLOP_16.php', 'The Secret Life of Pets (2016) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '28 July 2014', 'Animation', 'Eric Stonestreet, Kevin Hart, Louis C.K.', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('TTTIT_06.php', 'Teen Titans: Trouble in Tokyo (2006) Full Movie English 720p HDRip ESubs Download', '06 January 2018', 'Animation, Action, Comedy', 'Greg Cipes, Khary Payton, Scott Menville', 'English', '720p BluRay', ' English'),
('TT_12.php', 'Thadayara Thakka (2012) 720p Hindi HDRip Full Movie Download', '01 January 2012', 'Action', 'Arun Vijay, Rakul Preet Singh, Vamsi Krishna', 'Hindi', ' 720p HDRip', ''),
('TV_19.php', 'Thozhar Venkatesan (2019) Tamil Movie 720p Proper HDRip 1.3GB ESub', '12 July 2019', 'Drama', 'K. Hari Shankar, , Monica Chinnakotla, Mahashivan', 'Hindi', '720p HDRip', ''),
('TZP_07.php', 'Taare Zameen Par (2007) Full Movie [Hindi-DD5.1] 720p BluRay ESubs Download', '21 December 2017', '', ' Aamir Khan, Darsheel Safary, Tisca Chopra', 'Hindi DD5.1', '720p BluRay', 'English'),
('T_12.php', 'Thuppakki (2012) 720p Tamil BRRip Dual Audio Full Movie', '13 November 2012', 'Action, Crime', 'Kajal Aggarwal, Sathyan, Vidyut Jamwal', 'Hindi, Tamil', '720p HDRip', ''),
('T_16.php', 'Theri 2016 DVDRip Full Tamil Movie 480p Free Download', '14 April 2016', '', 'Amy Jackson, Mahendran, Samantha Ruth Prabhu', 'Tamil', '480p DVDRip', ''),
('T_S1.php', 'Titans Season 1 Dual Audio [Hindi-DD5.1] 720p HDRip ESubs Download', '12 October 2018', 'Action, Adventure, Crime', 'Anna Diop, Brenton Thwaites, Teagan Croft', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('VH_04.php', 'Van Helsing 2004 720p BRRip Tamil Dubbed Full Movie Download', '07 May 2004', 'Action, Adventure, Fantasy', 'David Wenham, ‎Hugh Jackman, Kate Beckinsale', 'Tamil', '720p BluRay', ''),
('V_S1.php', 'Vikings Season 1 Hindi Dubbed Web Series All Episodes 720p Free Download', '03 March 2013', 'War, Adventure, Drama', 'Katheryn Winnick, Travis Fimmel, Alexander Ludwig', 'Hindi + English', '720p BluRay', 'English'),
('V_S2.php', 'Vikings Season 2 Hindi Dubbed Web Series All Episodes 720p Free Download', '03 March 2013', 'War, Adventure, Drama', 'Katheryn Winnick, Travis Fimmel, Alexander Ludwig', 'Hindi, English', '720p BluRay', 'English'),
('V_S3.php', 'Vikings Season 3 Web Series All Episodes 720p Free Download', '03 March 2013', 'War, Adventure, Drama', 'Katheryn Winnick, Travis Fimmel, Alexander Ludwig', 'English', '720p BluRay', 'English'),
('V_S4.php', 'Vikings Season 4 COMPLETE BluRay 720p Free Download', '03 March 2013', 'War, Adventure, Drama', 'Katheryn Winnick, Travis Fimmel, Alexander Ludwig', 'Hindi, English', '720p BluRay', 'English'),
('V_S5.php', 'Vikings Season 5 (2018) Complete720p Download WEB-DL (S05E20) – Episode 20 Added', '03 March 2013', 'War, Adventure, Drama', 'Katheryn Winnick, Travis Fimmel, Alexander Ludwig', 'Hindi, English', '720p BluRay', 'English'),
('WA_S1.php', 'Wu Assassins Season 1 Dual Audio [Hindi-DD5.1] 720p HDRip ESubs Download', '08 August 2019', 'Action, Crime', 'Byron Mann, Iko Uwais, Katheryn Winnick', 'Hindi DD5.1, English', '720p HDRip', 'English'),
('WE_08.php', 'WALL-E (2008) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '25 September 2008', 'Animation, Adventure, Family', 'Ben Burtt, Elissa Knight, Jeff Garlin', 'Hindi DD5.1, English', '720p Bluray', 'English'),
('WF_18.php', 'White Fang (2018) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '04 October 2018', 'Animation, Adventure', 'Dominique Pinon, Raphaël Personnaz, Virginie Efira', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('WP_19.php', 'Wonder Park (2019) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '11 April 2019', 'Animation, Adventure, Comedy', 'Jennifer Garner, Ken Hudson Campbell, Sofia Mali', 'Hindi DD5.1(Itunes Audio), English DD5.1', '720p BluRay', 'English'),
('XMA_16.php', 'X-Men: Apocalypse (2016) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '19 May 2016', 'Action, Adventure, Sci-Fi', 'James McAvoy, Jennifer Lawrence, Michael Fassbender', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('XMDF_19.php', 'X-Men: Dark Phoenix (2019) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '06 June 2019', 'Action, Adventure, Sci-Fi', 'James McAvoy, Jennifer Lawrence, Michael Fassbender', 'Hindi DD5.1, English', '720p BluRay', 'English'),
('XMDOFP_14.php', 'X-Men: Days of Future Past (2014) Dual Audio [Hindi-DD5.1] 720p BluRay ESubs Download', '19 May 2016', 'Action, Adventure, Sci-Fi', 'Hugh Jackman, Ian McKellen, Patrick Stewar', 'Hindi DD5.1, English', '720p BluRay', 'English');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `email`, `password`, `id`) VALUES
('NewUser', 'NewUser@gmail.com', '202cb962ac59075b964b07152d234b70', 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`name`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
